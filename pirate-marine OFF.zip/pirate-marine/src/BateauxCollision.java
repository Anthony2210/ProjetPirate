import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class BateauxCollision extends JPanel implements ActionListener {
    private static final int LARGEUR_FENETRE = 800;
    private static final int HAUTEUR_FENETRE = 600;
    private static int LARGEUR_BATEAU = 50; // Largeur des bateaux
    private static int HAUTEUR_BATEAU = 50; // Hauteur des bateaux
    private static final int DELAI = 10;
    private static int NOMBRE_BATEAUX_MARINE=15; // Nombre de bateaux marins
    private static int NOMBRE_BATEAUX_PIRATE=15; // Nombre de bateaux pirates
    private static int VITESSE_MARINE = 2; // Vitesse de la marine
    private static int VITESSE_PIRATES = 2; // Vitesse des pirates
    private static final long EXPLOSION_DUREE = 1000; // Durée de l'explosion en millisecondes

    private List<Bateau> bateauxPirate;
    private List<Bateau> bateauxMarine;
    private Image bateauPimage; // Image pour les bateaux pirates
    private Image bateauMimage; // Image pour les bateaux marins
    private Image explosionImage; // Image pour l'explosion
    private boolean explosionActive = false;
    private int explosionX = 0;
    private int explosionY = 0;
    private long explosionDebut = 0;
    private Color couleurFond = new Color(30, 144, 255); // Couleur bleu marine

    private JSlider sliderVitesseMarine;
    private JSlider sliderVitessePirates;

    public BateauxCollision() {
        Timer timer = new Timer(DELAI, this);
        timer.start();

        bateauxPirate = new ArrayList<>();
        bateauxMarine = new ArrayList<>();

        // Chargez les images pour les bateaux pirates, marins et l'explosion
        ImageIcon bateauPIcon = new ImageIcon("bateauPimage.png");
        bateauPimage = bateauPIcon.getImage();

        ImageIcon bateauMIcon = new ImageIcon("bateauMimage.png");
        bateauMimage = bateauMIcon.getImage();

        ImageIcon explosionIcon = new ImageIcon("explosion.png");
        explosionImage = explosionIcon.getImage();

        Random random = new Random();

        for (int i = 0; i < NOMBRE_BATEAUX_PIRATE; i++) {
            bateauxPirate.add(new Bateau(Color.RED, random.nextInt(LARGEUR_FENETRE - LARGEUR_BATEAU), random.nextInt(HAUTEUR_FENETRE - HAUTEUR_BATEAU), bateauPimage));
        }

        for (int i = 0; i < NOMBRE_BATEAUX_MARINE; i++) {
            bateauxMarine.add(new Bateau(Color.BLUE, random.nextInt(LARGEUR_FENETRE - LARGEUR_BATEAU), random.nextInt(HAUTEUR_FENETRE - HAUTEUR_BATEAU), bateauMimage));
        }

        setBackground(couleurFond);
        setPreferredSize(new Dimension(LARGEUR_FENETRE, HAUTEUR_FENETRE));

        // Ajouter des curseurs pour régler la vitesse de la marine et des pirates
        sliderVitesseMarine = new JSlider(JSlider.HORIZONTAL, 1, 5, VITESSE_MARINE);
        sliderVitessePirates = new JSlider(JSlider.HORIZONTAL, 1, 5, VITESSE_PIRATES);

        sliderVitesseMarine.setMajorTickSpacing(1);
        sliderVitesseMarine.setPaintTicks(true);
        sliderVitesseMarine.setPaintLabels(true);

        sliderVitessePirates.setMajorTickSpacing(1);
        sliderVitessePirates.setPaintTicks(true);
        sliderVitessePirates.setPaintLabels(true);

        sliderVitesseMarine.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                VITESSE_MARINE = sliderVitesseMarine.getValue();
            }
        });

        sliderVitessePirates.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                VITESSE_PIRATES = sliderVitessePirates.getValue();
            }
        });

        JPanel panelSliders = new JPanel(new GridLayout(2, 2));
        panelSliders.add(new JLabel("Vitesse Marine:"));
        panelSliders.add(sliderVitesseMarine);
        panelSliders.add(new JLabel("Vitesse Pirates:"));
        panelSliders.add(sliderVitessePirates);

        add(panelSliders, BorderLayout.SOUTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (Bateau bateau : bateauxPirate) {
            bateau.dessiner(g);
        }

        for (Bateau bateau : bateauxMarine) {
            bateau.dessiner(g);
        }

        if (explosionActive) {
            long tempsActuel = System.currentTimeMillis();
            long tempsDepuisExplosion = tempsActuel - explosionDebut;

            if (tempsDepuisExplosion < EXPLOSION_DUREE) {
                g.drawImage(explosionImage, explosionX, explosionY, LARGEUR_BATEAU, HAUTEUR_BATEAU, null);
            } else {
                explosionActive = false;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Random random = new Random();

        // Faire en sorte que les bateaux pirates se déplacent de façon linéaire
        for (Bateau bateau : bateauxPirate) {
            Bateau bateauMarinPlusProche = trouverBateauPlusProche(bateau, bateauxMarine);
            if (bateauMarinPlusProche != null) {
                int dx = (bateauMarinPlusProche.x + LARGEUR_BATEAU / 2) - (bateau.x + LARGEUR_BATEAU / 2);
                int dy = (bateauMarinPlusProche.y + HAUTEUR_BATEAU / 2) - (bateau.y + HAUTEUR_BATEAU / 2);

                int distance = (int) Math.sqrt(dx * dx + dy * dy);
                if (distance > VITESSE_PIRATES) {
                    dx = (dx * VITESSE_PIRATES) / distance;
                    dy = (dy * VITESSE_PIRATES) / distance;
                }

                bateau.deplacer(dx, dy);
            }
        }

        // Faire en sorte que les bateaux marins suivent les bateaux pirates
        for (Bateau marine : bateauxMarine) {
            Bateau bateauPiratePlusProche = trouverBateauPlusProche(marine, bateauxPirate);
            if (bateauPiratePlusProche != null) {
                int dx = (bateauPiratePlusProche.x + LARGEUR_BATEAU / 2) - (marine.x + LARGEUR_BATEAU / 2);
                int dy = (bateauPiratePlusProche.y + HAUTEUR_BATEAU / 2) - (marine.y + HAUTEUR_BATEAU / 2);

                int distance = (int) Math.sqrt(dx * dx + dy * dy);
                if (distance > VITESSE_MARINE) {
                    dx = (dx * VITESSE_MARINE) / distance;
                    dy = (dy * VITESSE_MARINE) / distance;
                }

                marine.deplacer(dx, dy);
            }
        }

        // Gérer les collisions et faire disparaître aléatoirement un des bateaux
        Iterator<Bateau> iteratorPirate = bateauxPirate.iterator();
        while (iteratorPirate.hasNext()) {
            Bateau pirate = iteratorPirate.next();
            Iterator<Bateau> iteratorMarine = bateauxMarine.iterator();
            while (iteratorMarine.hasNext()) {
                Bateau marine = iteratorMarine.next();
                if (pirate.seToucheAvec(marine)) {
                    // Aléatoirement, l'un des deux bateaux disparaît et afficher une explosion
                    if (random.nextBoolean()) {
                        explosionActive = true;
                        explosionX = pirate.x + (LARGEUR_BATEAU - LARGEUR_BATEAU / 2);
                        explosionY = pirate.y + (HAUTEUR_BATEAU - HAUTEUR_BATEAU / 2);
                        explosionDebut = System.currentTimeMillis();
                        iteratorPirate.remove();
                    } else {
                        iteratorMarine.remove();
                        // Ajouter l'explosion pour les bateaux marins ici
                        explosionActive = true;
                        explosionX = marine.x + (LARGEUR_BATEAU - LARGEUR_BATEAU / 2);
                        explosionY = marine.y + (HAUTEUR_BATEAU - HAUTEUR_BATEAU / 2);
                        explosionDebut = System.currentTimeMillis();
                    }
                }
            }
        }

        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Bateaux Collision");
        BateauxCollision bateauxCollision = new BateauxCollision();
        frame.add(bateauxCollision);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private class Bateau {
        private Color couleur;
        private int x, y;
        private Image image;

        public Bateau(Color couleur, int x, int y, Image image) {
            this.couleur = couleur;
            this.x = x;
            this.y = y;
            this.image = image;
        }

        public void dessiner(Graphics g) {
            g.drawImage(image, x, y, LARGEUR_BATEAU, HAUTEUR_BATEAU, null);
        }

        public void deplacer(int dx, int dy) {
            x += dx;
            y += dy;

            if (x < 0) x = 0;
            if (x > LARGEUR_FENETRE - LARGEUR_BATEAU) x = LARGEUR_FENETRE - LARGEUR_BATEAU;
            if (y < 0) y = 0;
            if (y > HAUTEUR_FENETRE - HAUTEUR_BATEAU) y = HAUTEUR_FENETRE - HAUTEUR_BATEAU;
        }

        public boolean seToucheAvec(Bateau autreBateau) {
            return x + LARGEUR_BATEAU >= autreBateau.x && x <= autreBateau.x + LARGEUR_BATEAU
                    && y + HAUTEUR_BATEAU >= autreBateau.y && y <= autreBateau.y + HAUTEUR_BATEAU;
        }
    }

    private Bateau trouverBateauPlusProche(Bateau bateau, List<Bateau> listeBateaux) {
        Bateau plusProche = null;
        double distanceMin = Double.MAX_VALUE;

        for (Bateau autreBateau : listeBateaux) {
            if (autreBateau != bateau) {
                double distance = Math.sqrt(Math.pow(bateau.x - autreBateau.x, 2) + Math.pow(bateau.y - autreBateau.y, 2));
                if (distance < distanceMin) {
                    distanceMin = distance;
                    plusProche = autreBateau;
                }
            }
        }

        return plusProche;
    }
}
